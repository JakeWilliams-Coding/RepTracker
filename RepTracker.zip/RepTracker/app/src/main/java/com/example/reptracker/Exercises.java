package com.example.reptracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Exercises extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercises);


        Button but3 = (Button) findViewById(R.id.button3);
        Button but2 = (Button) findViewById(R.id.button2);
        Button but7 = (Button) findViewById(R.id.button7);


        but3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), LogTracker.class);
                view.getContext().startActivity(intent);
            }
        });


        but2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), MyProfile.class);
                view.getContext().startActivity(intent);
            }
        });


        but7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), Chest.class);
                view.getContext().startActivity(intent);
            }
        });




    }

}